-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Мар 09 2018 г., 03:56
-- Версия сервера: 10.1.30-MariaDB
-- Версия PHP: 7.1.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `6_hw`
--

-- --------------------------------------------------------

--
-- Структура таблицы `BASKETS`
--

CREATE TABLE `BASKETS` (
  `basket_id` int(8) NOT NULL,
  `item_id` int(11) NOT NULL,
  `count` int(16) NOT NULL,
  `option_id` int(8) NOT NULL,
  `user_id` int(8) NOT NULL,
  `is_ordered` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `BASKETS`
--

INSERT INTO `BASKETS` (`basket_id`, `item_id`, `count`, `option_id`, `user_id`, `is_ordered`) VALUES
(331, 3, 1, 1, 9, 0),
(381, 2, 2, 0, 9, 0),
(382, 6, 3, 1, 9, 0),
(385, 6, 2, 0, 9, 0),
(386, 2, 5, 1, 9, 0),
(387, 2, 3, 1, 7, 0),
(388, 3, 4, 0, 8, 0),
(389, 6, 2, 1, 8, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `ITEMS`
--

CREATE TABLE `ITEMS` (
  `item_id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `image_dir` varchar(64) NOT NULL,
  `image_min_dir` varchar(80) NOT NULL,
  `description` varchar(512) NOT NULL,
  `price` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `ITEMS`
--

INSERT INTO `ITEMS` (`item_id`, `name`, `image_dir`, `image_min_dir`, `description`, `price`) VALUES
(2, 'Хорошенькая Леди Звезда', './assets/img/ledi.jpg', './assets/img/min/ledi.jpg', 'Юный Чемпион России, Юный Чемпион НКП, \r\nЮный победитель НКП, Чемпион НКП, Победитель НКП, \r\nЧемпион России, Чемпион РКФ, Гранд Чемпион Росии,\r\n2*CACIB, JBIS-I, BIS-I, 2*BIS-II, \r\n3*BIG, Кандидат Чемпионы ISPU,\r\nЛучший производитель монопородки 2010', 'Безценен!'),
(3, 'Либенцверг Стелла', './assets/img/stella.jpg', './assets/img/min/stella.jpg', 'Лучший щенок.', 'Безценен.'),
(6, 'Паномакс Феррари', './assets/img/panomaks_ferrari.jpg', './assets/img/min/panomaks_ferrari.jpg', '4 Декабря 2014 года.\r\nЮный Чемпион России, Чемпион России,\r\nЧемпион НКП, Гранд Чемпион,\r\nЧемпион РКФ, CACIB.', '25000');

-- --------------------------------------------------------

--
-- Структура таблицы `ITEM_OPTIONS`
--

CREATE TABLE `ITEM_OPTIONS` (
  `option_id` int(11) NOT NULL,
  `option_name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `ITEM_OPTIONS`
--

INSERT INTO `ITEM_OPTIONS` (`option_id`, `option_name`) VALUES
(0, 'Кобель'),
(1, 'Сука');

-- --------------------------------------------------------

--
-- Структура таблицы `USERS`
--

CREATE TABLE `USERS` (
  `user_id` int(11) NOT NULL,
  `name` varchar(55) NOT NULL,
  `login` varchar(55) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_admin` int(1) NOT NULL,
  `e_mail` varchar(32) NOT NULL,
  `phone` int(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `USERS`
--

INSERT INTO `USERS` (`user_id`, `name`, `login`, `password`, `is_admin`, `e_mail`, `phone`) VALUES
(6, 'Артем', 'artem', '07db880791a8267ab70e1f590959506907db880791a8267ab70e1f5909595069', 1, '', 0),
(7, 'Q', 'q', 'd116db4599d9ddc8c35e61366a4f4967d116db4599d9ddc8c35e61366a4f4967', 0, '', 0),
(8, 'W', 'w', '86d5c0c77e4f72baec1b0d5a6810921f86d5c0c77e4f72baec1b0d5a6810921f', 0, '', 0),
(9, 'Admin', 'admin', '3cf108a4e0a498347a5a75a792f232123cf108a4e0a498347a5a75a792f23212', 1, '', 0),
(10, 'S', 's', '430f03c2ea70bd28108d593eca0c7c30430f03c2ea70bd28108d593eca0c7c30', 0, '', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `BASKETS`
--
ALTER TABLE `BASKETS`
  ADD PRIMARY KEY (`basket_id`);

--
-- Индексы таблицы `ITEMS`
--
ALTER TABLE `ITEMS`
  ADD PRIMARY KEY (`item_id`);

--
-- Индексы таблицы `USERS`
--
ALTER TABLE `USERS`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `BASKETS`
--
ALTER TABLE `BASKETS`
  MODIFY `basket_id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=390;

--
-- AUTO_INCREMENT для таблицы `ITEMS`
--
ALTER TABLE `ITEMS`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `USERS`
--
ALTER TABLE `USERS`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
